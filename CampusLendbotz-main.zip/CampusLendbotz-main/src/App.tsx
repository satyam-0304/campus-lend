import { FormEvent, useMemo, useState, type ChangeEvent, type ReactNode } from 'react';
import {
  ArrowRight,
  Bell,
  BookOpen,
  Check,
  ChevronDown,
  ChevronLeft,
  Compass,
  FileText,
  Laptop,
  LoaderCircle,
  LogOut,
  Menu,
  PackagePlus,
  Search,
  ShieldCheck,
  Sparkles,
  UserRound,
  X,
  XCircle,
} from 'lucide-react';

type Category = 'all' | 'academics' | 'electronics' | 'sports' | 'event_wear';
type Page = 'explore' | 'add' | 'dashboard' | 'profile';
type RequestStatus = 'pending' | 'approved' | 'rejected';

type Equipment = {
  equipment_id: string;
  equipment_name: string;
  category: Exclude<Category, 'all'>;
  status: 'available' | 'borrowed';
  owner: { id: string; full_name: string; room_number: string };
};

type BorrowRequest = {
  request_id: string;
  equipment_name: string;
  owner_name?: string;
  borrower_name?: string;
  borrower_room?: string;
  status: RequestStatus;
};

const equipmentSeed: Equipment[] = [
  { equipment_id: 'e1a2b3c4', equipment_name: 'Casio Fx-991EX Calculator', category: 'academics', status: 'available', owner: { id: 'u1', full_name: 'Satyam Kandpal', room_number: '204-B' } },
  { equipment_id: 'f5g6h7i8', equipment_name: 'Yonex Badminton Racket', category: 'sports', status: 'available', owner: { id: 'u2', full_name: 'Priya Sharma', room_number: '108-A' } },
  { equipment_id: 'j9k0l1m2', equipment_name: 'Dell Inspiron Laptop Stand', category: 'electronics', status: 'available', owner: { id: 'u3', full_name: 'Arjun Mehta', room_number: '312-C' } },
  { equipment_id: 'n3o4p5q6', equipment_name: 'Formal Black Blazer', category: 'event_wear', status: 'borrowed', owner: { id: 'u4', full_name: 'Ishita Rao', room_number: '218-A' } },
  { equipment_id: 'r7s8t9u0', equipment_name: 'USB-C Hub 7-in-1', category: 'electronics', status: 'available', owner: { id: 'u5', full_name: 'Rahul Singh', room_number: '406-B' } },
  { equipment_id: 'v1w2x3y4', equipment_name: 'Project Presentation Clicker', category: 'academics', status: 'available', owner: { id: 'u6', full_name: 'Neha Kapoor', room_number: '105-C' } },
];

const categoryLabels: Record<Exclude<Category, 'all'>, string> = {
  academics: 'Academics',
  electronics: 'Electronics',
  sports: 'Sports',
  event_wear: 'Event wear',
};

function App() {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [authMode, setAuthMode] = useState<'login' | 'signup'>('login');
  const [page, setPage] = useState<Page>('explore');
  const [mobileOpen, setMobileOpen] = useState(false);
  const [userMenuOpen, setUserMenuOpen] = useState(false);
  const [equipment, setEquipment] = useState(equipmentSeed);
  const [requests, setRequests] = useState<BorrowRequest[]>([
    { request_id: 'req-123', equipment_name: 'Casio Calculator', owner_name: 'Satyam', status: 'pending' },
  ]);
  const [incomingRequests, setIncomingRequests] = useState<BorrowRequest[]>([
    { request_id: 'req-987', equipment_name: 'USB-C Hub 7-in-1', borrower_name: 'Rahul', borrower_room: '305-C', status: 'pending' },
  ]);
  const [toast, setToast] = useState<string | null>(null);
  const [profile, setProfile] = useState({ full_name: 'Aarav Joshi', room_number: '204-B', phone_number: '+91 98765 43210' });

  if (!isAuthenticated) {
    return <AuthScreen mode={authMode} setMode={setAuthMode} onSuccess={() => setIsAuthenticated(true)} />;
  }

  const showToast = (message: string) => {
    setToast(message);
    window.setTimeout(() => setToast(null), 2800);
  };

  const addRequest = (item: Equipment) => {
    setRequests((current) => [...current, { request_id: `req-${Date.now()}`, equipment_name: item.equipment_name, owner_name: item.owner.full_name, status: 'pending' }]);
    showToast('Request sent to the owner');
  };

  const addEquipment = (item: Equipment) => {
    setEquipment((current) => [item, ...current]);
    showToast('Item added to the campus library');
    setPage('explore');
  };

  const updateIncoming = (requestId: string, status: RequestStatus) => {
    setIncomingRequests((current) => current.map((request) => request.request_id === requestId ? { ...request, status } : request));
    showToast(status === 'approved' ? 'Request approved' : 'Request declined');
  };

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900">
      <Navbar page={page} setPage={(next) => { setPage(next); setMobileOpen(false); }} mobileOpen={mobileOpen} setMobileOpen={setMobileOpen} userMenuOpen={userMenuOpen} setUserMenuOpen={setUserMenuOpen} onLogout={() => setIsAuthenticated(false)} />
      <main className="mx-auto max-w-7xl px-5 pb-16 pt-8 sm:px-8 lg:px-10">
        {page === 'explore' && <Explore equipment={equipment} requests={requests} onRequest={addRequest} />}
        {page === 'add' && <AddItem onAdd={addEquipment} onCancel={() => setPage('explore')} />}
        {page === 'dashboard' && <Dashboard requests={requests} incomingRequests={incomingRequests} onUpdate={updateIncoming} />}
        {page === 'profile' && <Profile profile={profile} setProfile={setProfile} onSave={() => showToast('Profile changes saved')} />}
      </main>
      {toast && <div className="fixed bottom-6 left-1/2 z-50 flex -translate-x-1/2 items-center gap-3 rounded-2xl bg-slate-900 px-5 py-3 text-sm font-semibold text-white shadow-2xl"><Check size={17} className="text-emerald-400" />{toast}</div>}
    </div>
  );
}

function AuthScreen({ mode, setMode, onSuccess }: { mode: 'login' | 'signup'; setMode: (mode: 'login' | 'signup') => void; onSuccess: () => void }) {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const submit = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    setError('');
    setLoading(true);
    window.setTimeout(() => { setLoading(false); onSuccess(); }, 650);
  };
  return (
    <div className="flex min-h-screen items-center justify-center bg-sky-50 px-5 py-10">
      <div className="w-full max-w-md">
        <div className="mb-8 text-center"><div className="mx-auto mb-4 flex h-14 w-14 items-center justify-center overflow-hidden rounded-2xl bg-white shadow-sm ring-1 ring-slate-200"><img src="/assets/images/logo.jpeg" alt="CampusLend" className="h-full w-full object-cover" /></div><h1 className="text-2xl font-extrabold tracking-tight text-slate-900">CampusLend</h1><p className="mt-2 text-sm text-slate-500">Share more. Carry less.</p></div>
        <div className="rounded-3xl bg-white p-6 shadow-xl shadow-slate-200/60 ring-1 ring-slate-100 sm:p-8">
          <div className="mb-7 grid grid-cols-2 rounded-xl bg-slate-50 p-1"><button onClick={() => setMode('login')} className={`rounded-lg py-2.5 text-sm font-bold transition ${mode === 'login' ? 'bg-white text-sky-700 shadow-sm' : 'text-slate-500'}`}>Log in</button><button onClick={() => setMode('signup')} className={`rounded-lg py-2.5 text-sm font-bold transition ${mode === 'signup' ? 'bg-white text-sky-700 shadow-sm' : 'text-slate-500'}`}>Sign up</button></div>
          <h2 className="text-xl font-extrabold">{mode === 'login' ? 'Welcome back' : 'Join your campus'}</h2><p className="mt-1 text-sm leading-6 text-slate-500">{mode === 'login' ? 'Find the things you need, right where you live.' : 'Create an account to lend and borrow with ease.'}</p>
          {error && <div className="mt-5 rounded-xl bg-rose-50 px-4 py-3 text-sm font-semibold text-rose-600">{error}</div>}
          <form onSubmit={submit} className="mt-6 space-y-4">{mode === 'signup' && <Field label="Full name" placeholder="Aarav Joshi" required />}<Field label="Email" type="email" placeholder="you@college.edu" required /><Field label="Password" type="password" placeholder="••••••••" required /><button disabled={loading} className="flex w-full items-center justify-center gap-2 rounded-xl bg-sky-600 py-3.5 text-sm font-extrabold text-white shadow-lg shadow-sky-600/20 transition hover:bg-sky-700 disabled:cursor-not-allowed disabled:opacity-70">{loading && <LoaderCircle size={17} className="animate-spin" />}{mode === 'login' ? 'Log in' : 'Create account'}<ArrowRight size={17} /></button></form>
          <p className="mt-6 text-center text-xs leading-5 text-slate-400">By continuing, you agree to keep your campus community safe and respectful.</p>
        </div>
      </div>
    </div>
  );
}

function Navbar({ page, setPage, mobileOpen, setMobileOpen, userMenuOpen, setUserMenuOpen, onLogout }: { page: Page; setPage: (page: Page) => void; mobileOpen: boolean; setMobileOpen: (open: boolean) => void; userMenuOpen: boolean; setUserMenuOpen: (open: boolean) => void; onLogout: () => void }) {
  const links: { id: Page; label: string; icon: typeof Compass }[] = [{ id: 'explore', label: 'Explore', icon: Compass }, { id: 'add', label: 'Add item', icon: PackagePlus }, { id: 'dashboard', label: 'Dashboard', icon: FileText }];
  return <header className="sticky top-0 z-40 border-b border-slate-200 bg-white/95 backdrop-blur"><div className="mx-auto flex h-18 max-w-7xl items-center justify-between px-5 sm:px-8 lg:px-10"><button onClick={() => setPage('explore')} className="flex items-center gap-3"><div className="h-9 w-9 overflow-hidden rounded-xl bg-sky-50 ring-1 ring-sky-100"><img src="/assets/images/logo.jpeg" alt="" className="h-full w-full object-cover" /></div><span className="text-lg font-extrabold tracking-tight">Campus<span className="text-sky-600">Lend</span></span></button><nav className="hidden items-center gap-1 md:flex">{links.map(({ id, label, icon: Icon }) => <button key={id} onClick={() => setPage(id)} className={`flex items-center gap-2 rounded-xl px-4 py-2.5 text-sm font-bold transition ${page === id ? 'bg-sky-50 text-sky-700' : 'text-slate-500 hover:bg-slate-50 hover:text-slate-900'}`}><Icon size={17} />{label}</button>)}</nav><div className="relative flex items-center gap-3"><button className="hidden rounded-xl p-2 text-slate-400 hover:bg-slate-50 hover:text-slate-700 sm:block"><Bell size={19} /></button><button onClick={() => setUserMenuOpen(!userMenuOpen)} className="flex items-center gap-2 rounded-full bg-slate-50 p-1.5 pr-2.5 transition hover:bg-slate-100"><div className="flex h-8 w-8 items-center justify-center rounded-full bg-sky-100 text-xs font-extrabold text-sky-700">AJ</div><ChevronDown size={15} className="text-slate-400" /></button>{userMenuOpen && <div className="absolute right-0 top-12 w-40 rounded-2xl border border-slate-100 bg-white p-2 shadow-xl"><button onClick={() => { setPage('profile'); setUserMenuOpen(false); }} className="flex w-full items-center gap-2 rounded-xl px-3 py-2.5 text-sm font-semibold text-slate-600 hover:bg-slate-50"><UserRound size={16} />Profile</button><button onClick={onLogout} className="flex w-full items-center gap-2 rounded-xl px-3 py-2.5 text-sm font-semibold text-rose-600 hover:bg-rose-50"><LogOut size={16} />Log out</button></div>}<button onClick={() => setMobileOpen(!mobileOpen)} className="rounded-xl p-2 text-slate-500 md:hidden">{mobileOpen ? <X size={21} /> : <Menu size={21} />}</button></div></div>{mobileOpen && <nav className="border-t border-slate-100 px-5 py-3 md:hidden">{links.map(({ id, label, icon: Icon }) => <button key={id} onClick={() => setPage(id)} className={`flex w-full items-center gap-3 rounded-xl px-3 py-3 text-sm font-bold ${page === id ? 'bg-sky-50 text-sky-700' : 'text-slate-600'}`}><Icon size={17} />{label}</button>)}</nav>}</header>;
}

function Explore({ equipment, requests, onRequest }: { equipment: Equipment[]; requests: BorrowRequest[]; onRequest: (item: Equipment) => void }) {
  const [search, setSearch] = useState('');
  const [category, setCategory] = useState<Category>('all');
  const filtered = useMemo(() => equipment.filter((item) => item.equipment_name.toLowerCase().includes(search.toLowerCase()) && (category === 'all' || item.category === category)), [equipment, search, category]);
  return <div><div className="mb-10 flex flex-col justify-between gap-6 lg:flex-row lg:items-end"><div><div className="mb-4 inline-flex items-center gap-2 rounded-full bg-amber-50 px-3 py-1.5 text-xs font-extrabold uppercase tracking-wider text-amber-700"><Sparkles size={14} /> Campus exchange</div><h1 className="max-w-xl text-4xl font-extrabold tracking-tight text-slate-900 sm:text-5xl">Borrow what you need.<br /><span className="text-sky-600">Lend what you can.</span></h1><p className="mt-4 max-w-lg text-base leading-7 text-slate-500">A simpler way to share useful things with the people around you.</p></div><div className="flex items-center gap-3 rounded-2xl border border-slate-200 bg-white px-4 py-3 shadow-sm"><div className="flex -space-x-2"><div className="h-8 w-8 rounded-full border-2 border-white bg-amber-100" /><div className="h-8 w-8 rounded-full border-2 border-white bg-sky-100" /><div className="h-8 w-8 rounded-full border-2 border-white bg-emerald-100" /></div><div><p className="text-sm font-extrabold">124 students</p><p className="text-xs text-slate-400">sharing on campus</p></div></div></div><div className="mb-7 flex flex-col gap-4"><div className="relative max-w-xl"><Search size={19} className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" /><input value={search} onChange={(event) => setSearch(event.target.value)} className="w-full rounded-2xl border border-slate-200 bg-white py-3.5 pl-12 pr-4 text-sm font-medium outline-none transition placeholder:text-slate-400 focus:border-sky-500 focus:ring-4 focus:ring-sky-500/10" placeholder="Search for calculators, rackets, adapters..." /></div><div className="flex gap-2 overflow-x-auto pb-1">{(['all', 'academics', 'electronics', 'sports', 'event_wear'] as Category[]).map((item) => <button key={item} onClick={() => setCategory(item)} className={`whitespace-nowrap rounded-full px-4 py-2 text-sm font-bold transition ${category === item ? 'bg-sky-600 text-white shadow-md shadow-sky-600/20' : 'border border-slate-200 bg-white text-slate-500 hover:border-sky-200 hover:text-sky-700'}`}>{item === 'all' ? 'All items' : categoryLabels[item]}</button>)}</div></div><div className="mb-4 flex items-center justify-between"><h2 className="text-lg font-extrabold">Available near you</h2><span className="text-sm font-semibold text-slate-400">{filtered.length} items</span></div>{filtered.length ? <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">{filtered.map((item) => <ItemCard key={item.equipment_id} item={item} alreadyRequested={requests.some((request) => request.equipment_name === item.equipment_name)} onRequest={onRequest} />)}</div> : <Empty icon={<Search size={26} />} title="No items found" text="Try a different search or category." />}</div>;
}

function ItemCard({ item, alreadyRequested, onRequest }: { item: Equipment; alreadyRequested: boolean; onRequest: (item: Equipment) => void }) { return <article className="group flex flex-col rounded-2xl border border-slate-200 bg-white p-5 transition hover:-translate-y-1 hover:border-sky-200 hover:shadow-xl hover:shadow-slate-200/60"><div className="mb-7 flex items-start justify-between"><div className="flex h-14 w-14 items-center justify-center rounded-2xl bg-sky-50 text-sky-600">{item.category === 'electronics' ? <Laptop size={26} /> : item.category === 'academics' ? <BookOpen size={26} /> : item.category === 'sports' ? <Compass size={26} /> : <Sparkles size={26} />}</div><span className={`rounded-full px-2.5 py-1 text-[11px] font-extrabold uppercase tracking-wide ${item.status === 'available' ? 'bg-emerald-50 text-emerald-600' : 'bg-slate-100 text-slate-400'}`}>{item.status}</span></div><div className="mb-5 flex-1"><p className="mb-1 text-xs font-bold uppercase tracking-wider text-sky-600">{categoryLabels[item.category]}</p><h3 className="text-base font-extrabold text-slate-900">{item.equipment_name}</h3><p className="mt-2 text-sm text-slate-500">Owned by <span className="font-bold text-slate-700">{item.owner.full_name}</span> · Room {item.owner.room_number}</p></div><button disabled={item.status !== 'available' || alreadyRequested} onClick={() => onRequest(item)} className="w-full rounded-xl bg-slate-900 py-3 text-sm font-extrabold text-white transition hover:bg-sky-600 disabled:cursor-not-allowed disabled:bg-slate-100 disabled:text-slate-400">{item.status !== 'available' ? 'Currently borrowed' : alreadyRequested ? 'Request sent' : 'Request to borrow'}</button></article>; }

function AddItem({ onAdd, onCancel }: { onAdd: (item: Equipment) => void; onCancel: () => void }) { const [name, setName] = useState(''); const [category, setCategory] = useState<Exclude<Category, 'all'>>('academics'); const [image, setImage] = useState(''); const submit = (event: FormEvent) => { event.preventDefault(); onAdd({ equipment_id: `item-${Date.now()}`, equipment_name: name, category, status: 'available', owner: { id: 'me', full_name: 'Aarav Joshi', room_number: '204-B' } }); }; return <div className="mx-auto max-w-2xl"><button onClick={onCancel} className="mb-8 flex items-center gap-2 text-sm font-bold text-slate-500 hover:text-sky-600"><ChevronLeft size={17} />Back to explore</button><div className="mb-8"><div className="mb-3 flex h-12 w-12 items-center justify-center rounded-2xl bg-amber-50 text-amber-600"><PackagePlus size={24} /></div><h1 className="text-3xl font-extrabold tracking-tight">Share an item</h1><p className="mt-2 text-slate-500">Give something useful a second life on campus.</p></div><form onSubmit={submit} className="rounded-3xl border border-slate-200 bg-white p-6 shadow-sm sm:p-8"><div className="space-y-6"><Field label="What are you sharing?" placeholder="e.g. Scientific calculator" value={name} onChange={(event) => setName(event.target.value)} required /><div><label className="mb-2 block text-sm font-bold text-slate-700">Category</label><select value={category} onChange={(event) => setCategory(event.target.value as Exclude<Category, 'all'>)} className="w-full rounded-xl border border-slate-200 bg-white px-4 py-3 text-sm font-medium outline-none focus:border-sky-500 focus:ring-4 focus:ring-sky-500/10"><option value="academics">Academics</option><option value="electronics">Electronics</option><option value="sports">Sports</option><option value="event_wear">Event wear</option></select></div><div><label className="mb-2 block text-sm font-bold text-slate-700">Item photo <span className="font-medium text-slate-400">(optional)</span></label><label className="flex cursor-pointer flex-col items-center justify-center rounded-2xl border-2 border-dashed border-slate-200 bg-slate-50 px-6 py-9 text-center transition hover:border-sky-300 hover:bg-sky-50"><input type="file" accept="image/*" className="hidden" onChange={(event) => setImage(event.target.files?.[0]?.name ?? '')} /><div className="mb-2 flex h-10 w-10 items-center justify-center rounded-full bg-white text-slate-400 shadow-sm">{image ? <Check size={20} className="text-emerald-500" /> : <PackagePlus size={19} />}</div><span className="text-sm font-bold text-slate-600">{image || 'Upload a clear photo'}</span><span className="mt-1 text-xs text-slate-400">PNG, JPG up to 5MB</span></label></div></div><button className="mt-8 flex w-full items-center justify-center gap-2 rounded-xl bg-sky-600 py-3.5 text-sm font-extrabold text-white shadow-lg shadow-sky-600/20 transition hover:bg-sky-700">List this item <ArrowRight size={17} /></button></form></div>; }

function Dashboard({ requests, incomingRequests, onUpdate }: { requests: BorrowRequest[]; incomingRequests: BorrowRequest[]; onUpdate: (id: string, status: RequestStatus) => void }) { return <div><div className="mb-8"><p className="mb-2 text-sm font-bold text-sky-600">Your activity</p><h1 className="text-3xl font-extrabold tracking-tight">Dashboard</h1><p className="mt-2 text-slate-500">Keep track of your lending and borrowing.</p></div><div className="grid gap-5 lg:grid-cols-2"><RequestSection title="My requests" subtitle="Items you asked to borrow" requests={requests} empty="You haven't requested anything yet." /><div className="rounded-3xl border border-slate-200 bg-white p-6 shadow-sm"><div className="mb-6"><h2 className="text-lg font-extrabold">Requests for my items</h2><p className="mt-1 text-sm text-slate-500">People waiting for your approval</p></div>{incomingRequests.length ? <div className="space-y-3">{incomingRequests.map((request) => <div key={request.request_id} className="rounded-2xl bg-slate-50 p-4"><div className="flex items-start justify-between gap-3"><div><h3 className="text-sm font-extrabold">{request.equipment_name}</h3><p className="mt-1 text-xs text-slate-500">{request.borrower_name} · Room {request.borrower_room}</p></div><Status status={request.status} /></div>{request.status === 'pending' && <div className="mt-4 flex gap-2"><button onClick={() => onUpdate(request.request_id, 'approved')} className="flex flex-1 items-center justify-center gap-1.5 rounded-lg bg-emerald-500 py-2 text-xs font-extrabold text-white hover:bg-emerald-600"><Check size={14} />Approve</button><button onClick={() => onUpdate(request.request_id, 'rejected')} className="flex flex-1 items-center justify-center gap-1.5 rounded-lg border border-slate-200 bg-white py-2 text-xs font-extrabold text-slate-500 hover:border-rose-200 hover:text-rose-600"><XCircle size={14} />Decline</button></div>}</div>)}</div> : <Empty icon={<Bell size={24} />} title="No requests yet" text="You'll see borrow requests here." />}</div></div></div>; }

function RequestSection({ title, subtitle, requests, empty }: { title: string; subtitle: string; requests: BorrowRequest[]; empty: string }) { return <div className="rounded-3xl border border-slate-200 bg-white p-6 shadow-sm"><div className="mb-6"><h2 className="text-lg font-extrabold">{title}</h2><p className="mt-1 text-sm text-slate-500">{subtitle}</p></div>{requests.length ? <div className="space-y-3">{requests.map((request) => <div key={request.request_id} className="flex items-center justify-between gap-3 rounded-2xl bg-slate-50 p-4"><div><h3 className="text-sm font-extrabold">{request.equipment_name}</h3><p className="mt-1 text-xs text-slate-500">Owner: {request.owner_name}</p></div><Status status={request.status} /></div>)}</div> : <Empty icon={<FileText size={24} />} title="Nothing here yet" text={empty} />}</div>; }

function Profile({ profile, setProfile, onSave }: { profile: { full_name: string; room_number: string; phone_number: string }; setProfile: (profile: { full_name: string; room_number: string; phone_number: string }) => void; onSave: () => void }) { return <div className="mx-auto max-w-2xl"><div className="mb-8"><p className="mb-2 text-sm font-bold text-sky-600">Your account</p><h1 className="text-3xl font-extrabold tracking-tight">Profile</h1><p className="mt-2 text-slate-500">Keep your details up to date for easy handoffs.</p></div><div className="rounded-3xl border border-slate-200 bg-white p-6 shadow-sm sm:p-8"><div className="mb-8 flex items-center gap-4"><div className="flex h-20 w-20 items-center justify-center rounded-full bg-sky-100 text-xl font-extrabold text-sky-700">AJ</div><div><h2 className="text-xl font-extrabold">{profile.full_name || 'Your name'}</h2><p className="mt-1 text-sm text-slate-400">CampusLend member</p></div></div><div className="space-y-5"><Field label="Full name" value={profile.full_name} onChange={(event) => setProfile({ ...profile, full_name: event.target.value })} /><Field label="Room number" value={profile.room_number} onChange={(event) => setProfile({ ...profile, room_number: event.target.value })} /><Field label="Phone number" value={profile.phone_number} onChange={(event) => setProfile({ ...profile, phone_number: event.target.value })} /></div><button onClick={onSave} className="mt-8 flex items-center gap-2 rounded-xl bg-sky-600 px-5 py-3 text-sm font-extrabold text-white shadow-lg shadow-sky-600/20 transition hover:bg-sky-700">Save changes <Check size={17} /></button></div><div className="mt-5 flex gap-3 rounded-2xl border border-emerald-100 bg-emerald-50 p-4 text-sm text-emerald-700"><ShieldCheck size={20} className="shrink-0" /><p><span className="font-extrabold">Your details are private.</span> Only your name and room number are shown when you list an item.</p></div></div>; }

function Status({ status }: { status: RequestStatus }) { return <span className={`rounded-full px-2.5 py-1 text-[11px] font-extrabold uppercase tracking-wide ${status === 'approved' ? 'bg-emerald-50 text-emerald-600' : status === 'rejected' ? 'bg-rose-50 text-rose-600' : 'bg-amber-50 text-amber-600'}`}>{status}</span>; }
function Empty({ icon, title, text }: { icon: ReactNode; title: string; text: string }) { return <div className="flex flex-col items-center justify-center rounded-2xl border border-dashed border-slate-200 px-6 py-12 text-center"><div className="mb-3 flex h-12 w-12 items-center justify-center rounded-full bg-slate-50 text-slate-400">{icon}</div><h3 className="text-sm font-extrabold">{title}</h3><p className="mt-1 text-sm text-slate-400">{text}</p></div>; }
function Field({ label, type = 'text', placeholder, value, onChange, required }: { label: string; type?: string; placeholder?: string; value?: string; onChange?: (event: ChangeEvent<HTMLInputElement>) => void; required?: boolean }) { return <div><label className="mb-2 block text-sm font-bold text-slate-700">{label}</label><input type={type} placeholder={placeholder} value={value} onChange={onChange} required={required} className="w-full rounded-xl border border-slate-200 bg-white px-4 py-3 text-sm font-medium outline-none transition placeholder:text-slate-300 focus:border-sky-500 focus:ring-4 focus:ring-sky-500/10" /></div>; }

export default App;
